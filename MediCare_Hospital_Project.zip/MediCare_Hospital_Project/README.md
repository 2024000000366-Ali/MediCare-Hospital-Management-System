# MediCare Hospital Management System

A simple Java Swing hospital management project for CSE282.

## Main concepts
- Encapsulation
- Abstraction
- Inheritance
- Polymorphism
- CRUD operations
- Text file handling
- Input validation
- Custom exception
- Java Swing GUI

## Run
Open the folder in IntelliJ IDEA, make sure JDK 17 (or a compatible modern JDK) is selected, then run `HospitalGUI.java`.

Patient data is stored in `data/patients.txt`.
