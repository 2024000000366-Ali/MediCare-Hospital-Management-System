public class Bill {
    private int patientId;
    private double amount;
    private String status;

    public Bill(int patientId, double amount, String status) {
        this.patientId = patientId;
        this.amount = amount;
        this.status = status;
    }

    public int getPatientId() { return patientId; }
    public double getAmount() { return amount; }
    public String getStatus() { return status; }

    public void setAmount(double amount) { this.amount = amount; }
    public void setStatus(String status) { this.status = status; }
}
