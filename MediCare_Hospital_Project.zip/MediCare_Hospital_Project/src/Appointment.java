public class Appointment {
    private int patientId;
    private int doctorId;
    private String date;

    public Appointment(int patientId, int doctorId, String date) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
    }

    public int getPatientId() { return patientId; }
    public int getDoctorId() { return doctorId; }
    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }
}
