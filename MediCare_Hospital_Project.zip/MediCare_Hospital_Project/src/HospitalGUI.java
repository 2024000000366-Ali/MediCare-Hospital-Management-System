import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;

public class HospitalGUI extends JFrame {
    private final JTextField idField = new JTextField();
    private final JTextField nameField = new JTextField();
    private final JTextField ageField = new JTextField();
    private final JTextField addressField = new JTextField();
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Name", "Age", "Address"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(tableModel);
    private PatientManager manager;

    public HospitalGUI() {
        try {
            manager = new PatientManager();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not open patient file.");
            manager = null;
        }

        setTitle("MediCare Hospital Management System");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        buildGui();
        refreshTable();
    }

    private void buildGui() {
        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Patient Information"));
        form.add(new JLabel("Patient ID:")); form.add(idField);
        form.add(new JLabel("Name:")); form.add(nameField);
        form.add(new JLabel("Age:")); form.add(ageField);
        form.add(new JLabel("Address:")); form.add(addressField);

        JButton addButton = new JButton("Add");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");
        JButton clearButton = new JButton("Clear");

        JPanel buttons = new JPanel();
        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(deleteButton);
        buttons.add(clearButton);

        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        addButton.addActionListener(e -> addPatient());
        updateButton.addActionListener(e -> updatePatient());
        deleteButton.addActionListener(e -> deletePatient());
        clearButton.addActionListener(e -> clearFields());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int row = table.getSelectedRow();
                idField.setText(tableModel.getValueAt(row, 0).toString());
                nameField.setText(tableModel.getValueAt(row, 1).toString());
                ageField.setText(tableModel.getValueAt(row, 2).toString());
                addressField.setText(tableModel.getValueAt(row, 3).toString());
            }
        });
    }

    private Patient readPatient() throws NumberFormatException {
        int id = Integer.parseInt(idField.getText().trim());
        int age = Integer.parseInt(ageField.getText().trim());
        return new Patient(id, nameField.getText().trim(), age, addressField.getText().trim());
    }

    private void addPatient() {
        try {
            manager.addPatient(readPatient());
            refreshTable();
            clearFields();
            showMessage("Patient added successfully.");
        } catch (NumberFormatException e) {
            showError("ID and Age must be numbers.");
        } catch (InvalidPatientException | IOException e) {
            showError(e.getMessage());
        }
    }

    private void updatePatient() {
        try {
            manager.updatePatient(readPatient());
            refreshTable();
            clearFields();
            showMessage("Patient updated successfully.");
        } catch (NumberFormatException e) {
            showError("ID and Age must be numbers.");
        } catch (InvalidPatientException | IOException e) {
            showError(e.getMessage());
        }
    }

    private void deletePatient() {
        try {
            int id = Integer.parseInt(idField.getText().trim());
            manager.deletePatient(id);
            refreshTable();
            clearFields();
            showMessage("Patient deleted successfully.");
        } catch (NumberFormatException e) {
            showError("Enter a valid patient ID.");
        } catch (InvalidPatientException | IOException e) {
            showError(e.getMessage());
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        if (manager == null) return;
        for (Patient patient : manager.getPatients()) {
            tableModel.addRow(new Object[]{patient.getId(), patient.getName(), patient.getAge(), patient.getAddress()});
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        addressField.setText("");
        table.clearSelection();
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HospitalGUI().setVisible(true));
    }
}
