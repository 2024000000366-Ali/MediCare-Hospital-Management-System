import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PatientManager {
    private final List<Patient> patients = new ArrayList<>();
    private final File file = new File("data/patients.txt");

    public PatientManager() throws IOException {
        loadPatients();
    }

    public List<Patient> getPatients() {
        return patients;
    }

    public void addPatient(Patient patient) throws InvalidPatientException, IOException {
        validate(patient);
        if (findPatient(patient.getId()) != null) {
            throw new InvalidPatientException("Patient ID already exists.");
        }
        patients.add(patient);
        savePatients();
    }

    public void updatePatient(Patient patient) throws InvalidPatientException, IOException {
        validate(patient);
        Patient old = findPatient(patient.getId());
        if (old == null) {
            throw new InvalidPatientException("Patient not found.");
        }
        old.setName(patient.getName());
        old.setAge(patient.getAge());
        old.setAddress(patient.getAddress());
        savePatients();
    }

    public void deletePatient(int id) throws InvalidPatientException, IOException {
        Patient patient = findPatient(id);
        if (patient == null) {
            throw new InvalidPatientException("Patient not found.");
        }
        patients.remove(patient);
        savePatients();
    }

    public Patient findPatient(int id) {
        for (Patient patient : patients) {
            if (patient.getId() == id) return patient;
        }
        return null;
    }

    private void validate(Patient patient) throws InvalidPatientException {
        if (patient.getId() <= 0) throw new InvalidPatientException("ID must be positive.");
        if (patient.getName() == null || patient.getName().trim().isEmpty())
            throw new InvalidPatientException("Name cannot be empty.");
        if (patient.getAge() <= 0 || patient.getAge() > 120)
            throw new InvalidPatientException("Age must be between 1 and 120.");
        if (patient.getAddress() == null || patient.getAddress().trim().isEmpty())
            throw new InvalidPatientException("Address cannot be empty.");
    }

    private void savePatients() throws IOException {
        File parent = file.getParentFile();
        if (parent != null) parent.mkdirs();
        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            for (Patient patient : patients) {
                writer.println(patient.getInfo());
            }
        }
    }

    private void loadPatients() throws IOException {
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length != 4) continue;
                try {
                    int id = Integer.parseInt(parts[0].trim());
                    String name = parts[1].trim();
                    int age = Integer.parseInt(parts[2].trim());
                    String address = parts[3].trim();
                    patients.add(new Patient(id, name, age, address));
                } catch (NumberFormatException ignored) {
                    // Skip invalid saved line.
                }
            }
        }
    }
}
