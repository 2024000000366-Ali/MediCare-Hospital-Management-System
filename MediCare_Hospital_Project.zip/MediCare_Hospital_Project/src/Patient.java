public class Patient extends Person {
    private String address;

    public Patient(int id, String name, int age, String address) {
        super(id, name, age);
        this.address = address;
    }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    @Override
    public String getRole() { return "Patient"; }

    @Override
    public String getInfo() {
        return getId() + "," + getName() + "," + getAge() + "," + address;
    }

    @Override
    public String toString() {
        return getId() + " - " + getName() + " - " + getAge() + " - " + address;
    }
}
