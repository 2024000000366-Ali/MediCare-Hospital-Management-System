package MediCare_Hospital_Project;

public class PatientManager {
}
